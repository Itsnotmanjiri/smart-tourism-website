import { useState, useEffect, useRef } from 'react';
import {
  Map, MapPin, Navigation, Search, X, ArrowLeft, Phone, 
  Share2, Star, Clock, DollarSign, Locate, Navigation2,
  Hotel, Utensils, Camera, ShoppingBag, ChevronRight, ExternalLink,
  Heart, Layers, Filter, Grid3x3, List, TrendingUp, Award,
  Car, Bus, Bike, Footprints, MapPinned, Timer
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

type LocationType = 
  | 'luxury-hotel' | 'budget-hotel' | 'resort' 
  | 'fine-dining' | 'street-food' | 'cafe' | 'bar'
  | 'fort' | 'palace' | 'temple' | 'mosque' | 'church' | 'museum' | 'park' | 'beach' | 'mountain' | 'monument'
  | 'mall' | 'market' | 'boutique';

interface Location {
  id: string;
  name: string;
  type: LocationType;
  lat: number;
  lng: number;
  address: string;
  rating: number;
  priceRange: string;
  phone: string;
  isOpen: boolean;
  description: string;
  city: string;
  category: 'hotels' | 'food' | 'attractions' | 'shopping';
  featured: boolean;
  distance?: number;
  travelTime?: {
    walking: string;
    driving: string;
    transit: string;
  };
}

interface City {
  name: string;
  lat: number;
  lng: number;
  emoji: string;
}

interface WorldClassGoogleMapsProps {
  onBack?: () => void;
  centerCity?: string;
}

export function WorldClassGoogleMaps({ onBack, centerCity = 'Delhi' }: WorldClassGoogleMapsProps) {
  const [selectedCity, setSelectedCity] = useState<City | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [mapType, setMapType] = useState<'street' | 'satellite'>('street');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [sortBy, setSortBy] = useState<'rating' | 'distance' | 'name'>('rating');
  const [showFeatured, setShowFeatured] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<any>(null);
  const markersLayerRef = useRef<any>(null);

  const cities: City[] = [
    { name: 'Delhi', lat: 28.6139, lng: 77.2090, emoji: '🏛️' },
    { name: 'Mumbai', lat: 19.0760, lng: 72.8777, emoji: '🏙️' },
    { name: 'Bangalore', lat: 12.9716, lng: 77.5946, emoji: '🌳' },
    { name: 'Goa', lat: 15.2993, lng: 74.1240, emoji: '🏖️' },
    { name: 'Jaipur', lat: 26.9124, lng: 75.7873, emoji: '🏰' },
    { name: 'Agra', lat: 27.1767, lng: 78.0081, emoji: '🕌' },
    { name: 'Kerala', lat: 10.8505, lng: 76.2711, emoji: '🌴' },
    { name: 'Varanasi', lat: 25.3176, lng: 82.9739, emoji: '🛕' },
    { name: 'Udaipur', lat: 24.5854, lng: 73.7125, emoji: '💎' },
    { name: 'Manali', lat: 32.2432, lng: 77.1892, emoji: '⛰️' },
    { name: 'Rishikesh', lat: 30.0869, lng: 78.2676, emoji: '🧘' },
  ];

  const categories = [
    { id: 'all', label: 'All Places', icon: Map, color: '#3B82F6' },
    { id: 'hotels', label: 'Hotels & Stays', icon: Hotel, color: '#8B5CF6' },
    { id: 'food', label: 'Food & Dining', icon: Utensils, color: '#F97316' },
    { id: 'attractions', label: 'Attractions', icon: Camera, color: '#10B981' },
    { id: 'shopping', label: 'Shopping', icon: ShoppingBag, color: '#EC4899' },
  ];

  // Get proper icon and color for each location type
  const getLocationDetails = (type: LocationType): { emoji: string; color: string; label: string } => {
    const details: Record<LocationType, { emoji: string; color: string; label: string }> = {
      // Hotels
      'luxury-hotel': { emoji: '🏨', color: '#8B5CF6', label: 'Luxury Hotel' },
      'budget-hotel': { emoji: '🏠', color: '#A78BFA', label: 'Budget Hotel' },
      'resort': { emoji: '🏝️', color: '#7C3AED', label: 'Resort' },
      
      // Food
      'fine-dining': { emoji: '🍽️', color: '#F97316', label: 'Fine Dining' },
      'street-food': { emoji: '🍜', color: '#FB923C', label: 'Street Food' },
      'cafe': { emoji: '☕', color: '#FDBA74', label: 'Café' },
      'bar': { emoji: '🍷', color: '#EA580C', label: 'Bar & Lounge' },
      
      // Attractions
      'fort': { emoji: '🏰', color: '#10B981', label: 'Fort' },
      'palace': { emoji: '👑', color: '#34D399', label: 'Palace' },
      'temple': { emoji: '🛕', color: '#6EE7B7', label: 'Temple' },
      'mosque': { emoji: '🕌', color: '#10B981', label: 'Mosque' },
      'church': { emoji: '⛪', color: '#059669', label: 'Church' },
      'museum': { emoji: '🏛️', color: '#047857', label: 'Museum' },
      'park': { emoji: '🌳', color: '#14B8A6', label: 'Park & Garden' },
      'beach': { emoji: '🏖️', color: '#06B6D4', label: 'Beach' },
      'mountain': { emoji: '⛰️', color: '#0891B2', label: 'Mountain' },
      'monument': { emoji: '🗿', color: '#0E7490', label: 'Monument' },
      
      // Shopping
      'mall': { emoji: '🏬', color: '#EC4899', label: 'Shopping Mall' },
      'market': { emoji: '🛒', color: '#F472B6', label: 'Market' },
      'boutique': { emoji: '👕', color: '#DB2777', label: 'Boutique' },
    };
    
    return details[type] || { emoji: '📍', color: '#3B82F6', label: 'Place' };
  };

  // Calculate distance between two points (Haversine formula)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  // Calculate travel time based on distance
  const calculateTravelTime = (distance: number) => {
    const walkingSpeed = 5; // km/h
    const drivingSpeed = 40; // km/h (city traffic)
    const transitSpeed = 30; // km/h (bus/metro)

    return {
      walking: distance < 0.5 ? '< 10 min' : `${Math.round((distance / walkingSpeed) * 60)} min`,
      driving: `${Math.round((distance / drivingSpeed) * 60)} min`,
      transit: `${Math.round((distance / transitSpeed) * 60)} min`,
    };
  };

  // MASSIVE location database - realistic numbers for each city
  const generateLocations = (city: City): Location[] => {
    const locations: Location[] = [];
    
    // HOTELS - 40+ per city
    const hotelNames = [
      'The Taj Palace', 'ITC Grand Central', 'Oberoi Heritage', 'Leela Palace', 'Radisson Blu',
      'Marriott Hotel', 'Hyatt Regency', 'JW Marriott', 'Holiday Inn', 'Novotel',
      'Hilton Garden Inn', 'Sheraton Grand', 'Westin Premium', 'Four Seasons', 'Ritz Carlton',
      'Crowne Plaza', 'Park Hyatt', 'Renaissance Hotel', 'Courtyard by Marriott', 'Fairmont',
      'Budget Inn', 'City Central Hotel', 'Comfort Suites', 'Red Fox Hotel', 'Treebo Trend',
      'OYO Rooms', 'FabExpress', 'Zostel Hostel', 'Backpacker\'s Inn', 'Hotel Suncity',
      'The Grand Residency', 'Royal Palace Hotel', 'Heritage Haveli', 'Lake View Resort', 'Beach Resort',
      'Mountain Lodge', 'Riverside Hotel', 'Airport Hotel', 'Business Inn', 'Tourist Lodge'
    ];

    hotelNames.forEach((name, index) => {
      const latOffset = (Math.random() - 0.5) * 0.12;
      const lngOffset = (Math.random() - 0.5) * 0.12;
      const type: LocationType = index < 15 ? 'luxury-hotel' : index < 30 ? 'budget-hotel' : 'resort';
      const rating = 3.5 + Math.random() * 1.5;
      const price = type === 'luxury-hotel' ? '₹₹₹₹' : type === 'resort' ? '₹₹₹' : '₹₹';
      
      locations.push({
        id: `${city.name}-hotel-${index}`,
        name: `${name} ${city.name}`,
        type,
        lat: city.lat + latOffset,
        lng: city.lng + lngOffset,
        address: `${Math.floor(Math.random() * 500) + 1} ${getStreetName('hotels')}, ${city.name}`,
        rating: parseFloat(rating.toFixed(1)),
        priceRange: price,
        phone: `+91 ${Math.floor(Math.random() * 90) + 10} ${Math.floor(Math.random() * 9000) + 1000} ${Math.floor(Math.random() * 9000) + 1000}`,
        isOpen: Math.random() > 0.1,
        description: `Experience comfort and luxury at ${name}. Perfect for business and leisure travelers.`,
        city: city.name,
        category: 'hotels',
        featured: index < 8,
      });
    });

    // RESTAURANTS & CAFES - 60+ per city
    const foodNames = [
      'Royal Fine Dining', 'Indian Spice Kitchen', 'The Curry House', 'Tandoori Nights', 'Saffron',
      'Street Food Hub', 'Punjabi Dhaba', 'Biryani Paradise', 'Momos Corner', 'Chaat Street',
      'Café Delight', 'Coastal Café', 'Coffee Culture', 'Barista', 'Starbucks',
      'Sunset Lounge', 'Sky Bar', 'The Vault Bar', 'Brewhouse', 'Cocktail Club',
      'Pizza Paradise', 'Burger Kingdom', 'Chinese Dragon', 'Thai Pavilion', 'Italian Bistro',
      'Dosa Corner', 'Idli House', 'Udupi Restaurant', 'Saravana Bhavan', 'MTR',
      'KFC', 'McDonald\'s', 'Subway', 'Domino\'s Pizza', 'Burger King',
      'Haldiram\'s', 'Bikanervala', 'Sagar Ratna', 'Nirula\'s', 'Karim\'s',
      'Paradise Biryani', 'Absolute Barbecue', 'Barbeque Nation', 'Mainland China', 'Oh! Calcutta',
      'Social', 'Hard Rock Cafe', 'TGI Friday\'s', 'Chili\'s', 'Texas Roadhouse',
      'The Breakfast Club', 'Smoke House Deli', 'The Fat Chef', 'Molecule Air Bar', 'Farzi Cafe',
      'Bakery Bliss', 'Sweet Tooth', 'Ice Cream Factory', 'Juice Bar', 'Health Cafe'
    ];

    foodNames.forEach((name, index) => {
      const latOffset = (Math.random() - 0.5) * 0.12;
      const lngOffset = (Math.random() - 0.5) * 0.12;
      const type: LocationType = index < 20 ? 'fine-dining' : index < 40 ? 'street-food' : index < 50 ? 'cafe' : 'bar';
      const rating = 3.5 + Math.random() * 1.5;
      const price = type === 'fine-dining' || type === 'bar' ? '₹₹₹' : type === 'cafe' ? '₹₹' : '₹';
      
      locations.push({
        id: `${city.name}-food-${index}`,
        name: `${name} ${city.name}`,
        type,
        lat: city.lat + latOffset,
        lng: city.lng + lngOffset,
        address: `${Math.floor(Math.random() * 500) + 1} ${getStreetName('food')}, ${city.name}`,
        rating: parseFloat(rating.toFixed(1)),
        priceRange: price,
        phone: `+91 ${Math.floor(Math.random() * 90) + 10} ${Math.floor(Math.random() * 9000) + 1000} ${Math.floor(Math.random() * 9000) + 1000}`,
        isOpen: Math.random() > 0.15,
        description: `Enjoy delicious cuisine at ${name}. A must-visit for food lovers!`,
        city: city.name,
        category: 'food',
        featured: index < 10,
      });
    });

    // SHOPPING - 50+ per city
    const shoppingNames = [
      'Select Citywalk', 'Ambience Mall', 'DLF Promenade', 'Phoenix Marketcity', 'Inorbit Mall',
      'Grand Mall', 'Central Plaza', 'Metropolitan Mall', 'Nexus Mall', 'Forum Mall',
      'Chandni Chowk', 'Local Bazaar', 'Heritage Market', 'Street Market', 'Flea Market',
      'Sarojini Nagar', 'Lajpat Nagar', 'Karol Bagh', 'Palika Bazaar', 'Janpath',
      'Fashion Street', 'Designer Boutique', 'Artisan Gallery', 'Craft Market', 'Handloom House',
      'Big Bazaar', 'Reliance Trends', 'Pantaloons', 'Lifestyle', 'Shoppers Stop',
      'Westside', 'Max Fashion', 'Brand Factory', 'Central', 'Landmark',
      'Fabindia', 'Forest Essentials', 'Good Earth', 'Anokhi', 'Khadi Gramodyog',
      'Zara', 'H&M', 'Uniqlo', 'Forever 21', 'Marks & Spencer',
      'Electronics Bazaar', 'Tech Hub', 'Computer Market', 'Mobile Plaza', 'Gadget Store',
      'Jewelry Market', 'Gold Souk', 'Diamond Plaza', 'Silver Street', 'Gem Gallery'
    ];

    shoppingNames.forEach((name, index) => {
      const latOffset = (Math.random() - 0.5) * 0.12;
      const lngOffset = (Math.random() - 0.5) * 0.12;
      const type: LocationType = index < 20 ? 'mall' : index < 40 ? 'market' : 'boutique';
      const rating = 3.5 + Math.random() * 1.5;
      const price = type === 'mall' || type === 'boutique' ? '₹₹₹' : '₹₹';
      
      locations.push({
        id: `${city.name}-shopping-${index}`,
        name: `${name} ${city.name}`,
        type,
        lat: city.lat + latOffset,
        lng: city.lng + lngOffset,
        address: `${Math.floor(Math.random() * 500) + 1} ${getStreetName('shopping')}, ${city.name}`,
        rating: parseFloat(rating.toFixed(1)),
        priceRange: price,
        phone: `+91 ${Math.floor(Math.random() * 90) + 10} ${Math.floor(Math.random() * 9000) + 1000} ${Math.floor(Math.random() * 9000) + 1000}`,
        isOpen: Math.random() > 0.1,
        description: `Shop till you drop at ${name}. Best shopping experience in ${city.name}!`,
        city: city.name,
        category: 'shopping',
        featured: index < 10,
      });
    });

    // ATTRACTIONS - 30+ per city
    const attractionNames = [
      'Heritage Fort', 'City Fort', 'Ancient Fort', 'Royal Palace', 'Lake Palace', 'City Palace',
      'Ancient Temple', 'Golden Temple', 'Shiva Temple', 'Historic Mosque', 'Jama Masjid',
      'Colonial Church', 'St. Cathedral', 'National Museum', 'Art Gallery', 'Science Museum',
      'Botanical Gardens', 'Rose Garden', 'City Park', 'Sunset Beach', 'Main Beach',
      'Mountain Viewpoint', 'Hill Station', 'Victory Monument', 'War Memorial', 'Clock Tower',
      'Zoo & Safari', 'Aquarium', 'Planetarium', 'Adventure Park', 'Water Park'
    ];

    attractionNames.forEach((name, index) => {
      const latOffset = (Math.random() - 0.5) * 0.12;
      const lngOffset = (Math.random() - 0.5) * 0.12;
      const types: LocationType[] = ['fort', 'palace', 'temple', 'mosque', 'church', 'museum', 'park', 'beach', 'mountain', 'monument'];
      const type = types[index % types.length];
      const rating = 4.0 + Math.random() * 1.0;
      const price = index < 10 ? '₹₹' : index < 20 ? '₹' : 'Free';
      
      locations.push({
        id: `${city.name}-attraction-${index}`,
        name: `${name} ${city.name}`,
        type,
        lat: city.lat + latOffset,
        lng: city.lng + lngOffset,
        address: `${Math.floor(Math.random() * 500) + 1} ${getStreetName('attractions')}, ${city.name}`,
        rating: parseFloat(rating.toFixed(1)),
        priceRange: price,
        phone: `+91 ${Math.floor(Math.random() * 90) + 10} ${Math.floor(Math.random() * 9000) + 1000} ${Math.floor(Math.random() * 9000) + 1000}`,
        isOpen: Math.random() > 0.05,
        description: `Discover the beauty of ${name}. A top-rated attraction in ${city.name}!`,
        city: city.name,
        category: 'attractions',
        featured: index < 8,
      });
    });

    return locations;
  };

  const getStreetName = (category: string): string => {
    const streets: Record<string, string[]> = {
      hotels: ['MG Road', 'Park Street', 'Connaught Place', 'Marine Drive', 'Central Avenue', 'Mall Road'],
      food: ['Food Street', 'Restaurant Row', 'Culinary Lane', 'Taste Boulevard', 'Dining District', 'Flavor Avenue'],
      attractions: ['Heritage Road', 'Monument Circle', 'Cultural Avenue', 'Historic Plaza', 'Tourist Street', 'Landmark Road'],
      shopping: ['Shopping Street', 'Market Road', 'Fashion Avenue', 'Bazaar Lane', 'Commercial Street', 'Retail Hub'],
    };
    
    const options = streets[category] || streets.shopping;
    return options[Math.floor(Math.random() * options.length)];
  };

  // Update locations with distance when user location changes
  useEffect(() => {
    if (userLocation && locations.length > 0) {
      const updatedLocations = locations.map(location => {
        const distance = calculateDistance(
          userLocation.lat,
          userLocation.lng,
          location.lat,
          location.lng
        );
        return {
          ...location,
          distance,
          travelTime: calculateTravelTime(distance),
        };
      });
      setLocations(updatedLocations);
    }
  }, [userLocation]);

  // Initialize city
  useEffect(() => {
    const initCity = cities.find(c => c.name === centerCity) || cities[0];
    setSelectedCity(initCity);
    setLocations(generateLocations(initCity));
  }, [centerCity]);

  // Load Leaflet
  useEffect(() => {
    if (!mapRef.current || !selectedCity) return;

    const loadLeaflet = async () => {
      if (!document.getElementById('leaflet-css')) {
        const link = document.createElement('link');
        link.id = 'leaflet-css';
        link.rel = 'stylesheet';
        link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        document.head.appendChild(link);
      }

      if (!(window as any).L) {
        const script = document.createElement('script');
        script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        script.onload = () => initializeMap();
        document.head.appendChild(script);
      } else {
        initializeMap();
      }
    };

    loadLeaflet();

    return () => {
      if (leafletMapRef.current) {
        leafletMapRef.current.remove();
        leafletMapRef.current = null;
      }
    };
  }, [selectedCity, mapType]);

  const initializeMap = () => {
    if (!mapRef.current || !selectedCity || !(window as any).L) return;

    const L = (window as any).L;

    if (leafletMapRef.current) {
      leafletMapRef.current.remove();
    }

    const map = L.map(mapRef.current).setView([selectedCity.lat, selectedCity.lng], 13);

    if (mapType === 'satellite') {
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Esri',
        maxZoom: 19,
      }).addTo(map);
    } else {
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap',
        maxZoom: 19,
      }).addTo(map);
    }

    leafletMapRef.current = map;

    if (markersLayerRef.current) {
      markersLayerRef.current.clearLayers();
    } else {
      markersLayerRef.current = L.layerGroup().addTo(map);
    }

    locations.forEach(location => {
      const details = getLocationDetails(location.type);
      
      const markerIcon = L.divIcon({
        className: 'custom-marker',
        html: `
          <div style="position: relative;">
            <div style="
              background: linear-gradient(135deg, ${details.color} 0%, ${details.color}dd 100%);
              width: 40px;
              height: 40px;
              border-radius: 50% 50% 50% 0;
              transform: rotate(-45deg);
              border: 3px solid white;
              box-shadow: 0 4px 16px rgba(0,0,0,0.35);
              display: flex;
              align-items: center;
              justify-content: center;
              ${location.featured ? 'animation: bounce 2s infinite;' : ''}
            ">
              <span style="
                transform: rotate(45deg);
                font-size: 20px;
                display: block;
              ">${details.emoji}</span>
            </div>
            ${location.featured ? `<div style="
              position: absolute;
              top: -6px;
              right: -6px;
              background: #FFD700;
              width: 18px;
              height: 18px;
              border-radius: 50%;
              border: 2px solid white;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 9px;
            ">⭐</div>` : ''}
          </div>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 40],
        popupAnchor: [0, -40],
      });

      const marker = L.marker([location.lat, location.lng], { icon: markerIcon })
        .addTo(markersLayerRef.current)
        .on('click', () => {
          setSelectedLocation(location);
          map.setView([location.lat, location.lng], 15);
        });

      const distanceInfo = location.distance 
        ? `<div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #E5E7EB;">
             <span style="color: #3B82F6; font-weight: bold;">📍 ${location.distance.toFixed(1)} km away</span>
           </div>`
        : '';

      marker.bindPopup(`
        <div style="text-align: center; min-width: 200px;">
          <div style="font-size: 20px; margin-bottom: 5px;">${details.emoji}</div>
          <strong style="font-size: 15px; color: #1F2937;">${location.name}</strong><br>
          <span style="color: #6B7280; font-size: 12px;">${details.label}</span><br>
          <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #E5E7EB;">
            <span style="color: #F59E0B; font-weight: bold;">⭐ ${location.rating}</span>
            <span style="margin: 0 8px; color: #D1D5DB;">•</span>
            <span style="color: ${location.isOpen ? '#10B981' : '#EF4444'}; font-weight: bold;">${location.isOpen ? '✅ Open' : '🔴 Closed'}</span>
          </div>
          ${distanceInfo}
          ${location.featured ? '<div style="margin-top: 8px; background: #FEF3C7; padding: 4px 8px; border-radius: 4px; font-size: 11px; color: #92400E;">⭐ Featured</div>' : ''}
        </div>
      `);
    });

    if (userLocation) {
      const userIcon = L.divIcon({
        className: 'user-marker-pulse',
        html: `
          <div style="position: relative;">
            <div class="pulse-ring"></div>
            <div style="
              background: #4285F4;
              width: 24px;
              height: 24px;
              border-radius: 50%;
              border: 4px solid white;
              box-shadow: 0 3px 12px rgba(66, 133, 244, 0.6);
              position: relative;
              z-index: 10;
            "></div>
          </div>
        `,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });

      L.marker([userLocation.lat, userLocation.lng], { icon: userIcon })
        .addTo(markersLayerRef.current)
        .bindPopup('<strong>📍 Your Location</strong>')
        .openPopup();
    }
  };

  const handleCityChange = (city: City) => {
    setSelectedCity(city);
    setSelectedLocation(null);
    setSearchQuery('');
    const newLocations = generateLocations(city);
    setLocations(newLocations);
    setUserLocation(null);
    toast.success(`📍 Exploring ${city.name}!`);
  };

  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      toast.error('❌ Geolocation not supported');
      return;
    }

    toast.info('📍 Getting your location...');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userPos = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setUserLocation(userPos);

        // Update all locations with distance
        const updatedLocations = locations.map(location => {
          const distance = calculateDistance(
            userPos.lat,
            userPos.lng,
            location.lat,
            location.lng
          );
          return {
            ...location,
            distance,
            travelTime: calculateTravelTime(distance),
          };
        });
        setLocations(updatedLocations);

        if (leafletMapRef.current) {
          const L = (window as any).L;
          leafletMapRef.current.setView([userPos.lat, userPos.lng], 15);

          const userIcon = L.divIcon({
            className: 'user-marker-pulse',
            html: `
              <div style="position: relative;">
                <div class="pulse-ring"></div>
                <div style="
                  background: #4285F4;
                  width: 24px;
                  height: 24px;
                  border-radius: 50%;
                  border: 4px solid white;
                  box-shadow: 0 3px 12px rgba(66, 133, 244, 0.6);
                  position: relative;
                  z-index: 10;
                "></div>
              </div>
            `,
            iconSize: [24, 24],
            iconAnchor: [12, 12],
          });

          L.marker([userPos.lat, userPos.lng], { icon: userIcon })
            .addTo(markersLayerRef.current)
            .bindPopup('<strong>📍 Your Location</strong>')
            .openPopup();
        }

        toast.success('✅ Location found! Distances calculated!');
      },
      () => {
        toast.error('❌ Unable to get location. Enable GPS!');
      }
    );
  };

  const handleGetDirections = (location: Location) => {
    if (userLocation) {
      const origin = `${userLocation.lat},${userLocation.lng}`;
      const destination = `${location.lat},${location.lng}`;
      const url = `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}&travelmode=driving`;
      window.open(url, '_blank');
      toast.success(`🧭 Navigating to ${location.name}!`);
    } else {
      const destination = `${location.lat},${location.lng}`;
      const url = `https://www.google.com/maps/dir/?api=1&destination=${destination}`;
      window.open(url, '_blank');
      toast.info(`🧭 Opening ${location.name}. Enable location for directions!`);
    }
  };

  const handleShare = (location?: Location) => {
    const shareData = location
      ? {
          title: location.name,
          text: `Check out ${location.name}! ${getLocationDetails(location.type).emoji} Rating: ${location.rating}⭐`,
          url: `https://www.google.com/maps/search/?api=1&query=${location.lat},${location.lng}`,
        }
      : {
          title: `Explore ${selectedCity?.name}`,
          text: `Discover amazing places in ${selectedCity?.name}!`,
          url: window.location.href,
        };

    if (navigator.share) {
      navigator.share(shareData)
        .then(() => toast.success('✅ Shared!'))
        .catch(() => {
          navigator.clipboard.writeText(shareData.url);
          toast.success('📋 Link copied!');
        });
    } else {
      navigator.clipboard.writeText(shareData.url);
      toast.success('📋 Link copied!');
    }
  };

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
    toast.success('📞 Opening dialer...');
  };

  const handleOpenInGoogleMaps = (location: Location) => {
    const url = `https://www.google.com/maps/search/?api=1&query=${location.lat},${location.lng}`;
    window.open(url, '_blank');
    toast.success('🗺️ Opening Google Maps!');
  };

  const handleFavoriteToggle = (locationId: string) => {
    setFavorites(prev => {
      if (prev.includes(locationId)) {
        toast.success('💔 Removed from favorites');
        return prev.filter(id => id !== locationId);
      } else {
        toast.success('❤️ Added to favorites!');
        return [...prev, locationId];
      }
    });
  };

  // Filter and sort locations
  let filteredLocations = locations.filter(location => {
    if (selectedCategory !== 'all' && location.category !== selectedCategory) return false;
    if (showFeatured && !location.featured) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const details = getLocationDetails(location.type);
      return (
        location.name.toLowerCase().includes(query) ||
        location.address.toLowerCase().includes(query) ||
        details.label.toLowerCase().includes(query)
      );
    }
    return true;
  });

  // Sort locations
  filteredLocations = [...filteredLocations].sort((a, b) => {
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'distance' && a.distance !== undefined && b.distance !== undefined) return a.distance - b.distance;
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    return 0;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 via-purple-900 to-blue-900 text-white p-4 sticky top-0 z-30 shadow-2xl">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            {onBack && (
              <button
                onClick={onBack}
                className="p-2 hover:bg-white/20 rounded-xl transition-all"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="flex-1">
              <h1 className="text-2xl flex items-center gap-3">
                <MapPinned className="w-7 h-7" />
                Explore Maps
              </h1>
              <p className="text-sm text-white/90 mt-1">
                {selectedCity?.name} • {filteredLocations.length} places • {locations.filter(l => l.category === 'shopping').length} shopping spots
              </p>
            </div>
            <button
              onClick={handleLocateMe}
              className="flex items-center gap-2 bg-white text-blue-900 px-5 py-2.5 rounded-xl hover:bg-blue-50 transition-all shadow-lg"
            >
              <Locate className="w-5 h-5" />
              <span className="hidden md:inline">Find Me</span>
            </button>
          </div>

          {/* City Selector */}
          <div className="flex gap-2 overflow-x-auto pb-2 hide-scrollbar">
            {cities.map((city) => (
              <button
                key={city.name}
                onClick={() => handleCityChange(city)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
                  selectedCity?.name === city.name
                    ? 'bg-white text-blue-900 shadow-xl scale-105'
                    : 'bg-white/15 hover:bg-white/25 backdrop-blur-sm'
                }`}
              >
                <span className="text-xl">{city.emoji}</span>
                <span className="text-sm">{city.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4">
        {/* Stats Banner */}
        <div className="bg-white rounded-2xl shadow-xl p-4 mb-4">
          <div className="grid grid-cols-4 gap-4 text-center">
            <div className="p-3 bg-purple-50 rounded-xl">
              <div className="text-2xl text-purple-600">{locations.filter(l => l.category === 'hotels').length}</div>
              <div className="text-xs text-gray-600 mt-1">Hotels</div>
            </div>
            <div className="p-3 bg-orange-50 rounded-xl">
              <div className="text-2xl text-orange-600">{locations.filter(l => l.category === 'food').length}</div>
              <div className="text-xs text-gray-600 mt-1">Restaurants</div>
            </div>
            <div className="p-3 bg-green-50 rounded-xl">
              <div className="text-2xl text-green-600">{locations.filter(l => l.category === 'attractions').length}</div>
              <div className="text-xs text-gray-600 mt-1">Attractions</div>
            </div>
            <div className="p-3 bg-pink-50 rounded-xl">
              <div className="text-2xl text-pink-600">{locations.filter(l => l.category === 'shopping').length}</div>
              <div className="text-xs text-gray-600 mt-1">Shopping</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {/* Search & Filters */}
            <div className="bg-white rounded-2xl shadow-xl p-5">
              <div className="relative mb-4">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search places, attractions..."
                  className="w-full pl-12 pr-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500 transition-all"
                />
              </div>

              {/* Quick Filters */}
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setShowFeatured(!showFeatured)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all ${
                    showFeatured
                      ? 'bg-yellow-100 text-yellow-800 border-2 border-yellow-300'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  Featured
                </button>
                <button
                  onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm bg-gray-100 text-gray-600 hover:bg-gray-200 transition-all"
                >
                  {viewMode === 'list' ? <Grid3x3 className="w-4 h-4" /> : <List className="w-4 h-4" />}
                </button>
              </div>

              {/* Sort Options */}
              <div>
                <label className="text-xs text-gray-600 mb-2 block">Sort By</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                >
                  <option value="rating">⭐ Highest Rated</option>
                  <option value="distance">📍 Nearest First</option>
                  <option value="name">🔤 Name (A-Z)</option>
                </select>
              </div>
            </div>

            {/* Category Filter */}
            <div className="bg-white rounded-2xl shadow-xl p-5">
              <h3 className="text-sm text-gray-600 mb-4 flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Categories
              </h3>
              <div className="space-y-2">
                {categories.map((category) => {
                  const Icon = category.icon;
                  const count = category.id === 'all'
                    ? locations.length
                    : locations.filter(l => l.category === category.id).length;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full flex items-center gap-3 p-3.5 rounded-xl transition-all transform hover:scale-102 ${
                        selectedCategory === category.id
                          ? 'text-white shadow-lg'
                          : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                      }`}
                      style={{
                        background: selectedCategory === category.id ? category.color : undefined,
                      }}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="flex-1 text-left">{category.label}</span>
                      <span className={`text-sm px-2.5 py-0.5 rounded-full ${
                        selectedCategory === category.id
                          ? 'bg-white/20'
                          : 'bg-gray-200'
                      }`}>{count}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Locations List */}
            <div className="bg-white rounded-2xl shadow-xl p-5 max-h-[600px] overflow-y-auto">
              <h3 className="text-sm text-gray-600 mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                {filteredLocations.length} Places Found
              </h3>
              <div className="space-y-2">
                {filteredLocations.map((location) => {
                  const details = getLocationDetails(location.type);
                  return (
                    <button
                      key={location.id}
                      onClick={() => {
                        setSelectedLocation(location);
                        if (leafletMapRef.current) {
                          leafletMapRef.current.setView([location.lat, location.lng], 16);
                        }
                      }}
                      className={`w-full text-left p-3 rounded-xl transition-all border-2 relative ${
                        selectedLocation?.id === location.id
                          ? 'bg-blue-50 border-blue-500 shadow-lg'
                          : 'bg-gray-50 border-transparent hover:bg-gray-100 hover:border-gray-200'
                      }`}
                    >
                      {location.featured && (
                        <div className="absolute top-2 right-2 bg-yellow-400 text-yellow-900 text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Award className="w-3 h-3" />
                        </div>
                      )}
                      <div className="flex items-start gap-3">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                          style={{ background: `${details.color}20`, color: details.color }}
                        >
                          {details.emoji}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-gray-900 truncate text-sm">{location.name}</h4>
                          <p className="text-xs text-gray-500 truncate">{details.label}</p>
                          <div className="flex items-center gap-2 mt-1.5 text-xs flex-wrap">
                            <span className="flex items-center gap-1 text-yellow-600">
                              <Star className="w-3 h-3 fill-current" />
                              {location.rating}
                            </span>
                            {location.distance !== undefined && (
                              <>
                                <span className="text-gray-400">•</span>
                                <span className="flex items-center gap-1 text-blue-600">
                                  <MapPin className="w-3 h-3" />
                                  {location.distance.toFixed(1)} km
                                </span>
                              </>
                            )}
                            <span className="text-gray-400">•</span>
                            <span className={location.isOpen ? 'text-green-600' : 'text-red-600'}>
                              {location.isOpen ? '✓ Open' : '✕ Closed'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Map Container */}
          <div className="lg:col-span-2 space-y-4">
            {/* Map */}
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden h-[600px] relative">
              <div ref={mapRef} className="w-full h-full" />
              
              {/* Map Controls */}
              <div className="absolute top-4 right-4 bg-white rounded-xl shadow-xl p-2">
                <button
                  onClick={() => setMapType(mapType === 'street' ? 'satellite' : 'street')}
                  className="p-3 hover:bg-gray-100 rounded-lg transition-all"
                  title="Toggle Map Type"
                >
                  <Layers className="w-5 h-5 text-gray-700" />
                </button>
              </div>

              {/* Stats Badge */}
              <div className="absolute top-4 left-4 bg-white rounded-xl shadow-xl px-4 py-2">
                <div className="flex items-center gap-2 text-sm text-gray-900">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>{filteredLocations.length} places showing</span>
                </div>
              </div>
            </div>

            {/* Selected Location Details */}
            {selectedLocation && (
              <div className="bg-white rounded-2xl shadow-xl p-6">
                <div className="flex items-start justify-between mb-5">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-4xl">{getLocationDetails(selectedLocation.type).emoji}</span>
                      <div>
                        <h2 className="text-2xl text-gray-900">{selectedLocation.name}</h2>
                        <p className="text-sm text-gray-500">{getLocationDetails(selectedLocation.type).label}</p>
                      </div>
                    </div>
                    <p className="text-gray-600 flex items-center gap-2 text-sm">
                      <MapPin className="w-4 h-4" />
                      {selectedLocation.address}
                    </p>
                    {selectedLocation.distance !== undefined && (
                      <p className="text-blue-600 flex items-center gap-2 text-sm mt-2">
                        <Navigation className="w-4 h-4" />
                        {selectedLocation.distance.toFixed(1)} km away from you
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleFavoriteToggle(selectedLocation.id)}
                      className={`p-3 rounded-xl transition-all ${
                        favorites.includes(selectedLocation.id)
                          ? 'bg-red-50 text-red-600'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      <Heart className={`w-5 h-5 ${favorites.includes(selectedLocation.id) ? 'fill-current' : ''}`} />
                    </button>
                    <button
                      onClick={() => setSelectedLocation(null)}
                      className="p-3 hover:bg-gray-100 rounded-xl transition-all"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {/* How to Get There */}
                {selectedLocation.travelTime && (
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-4 mb-5">
                    <h3 className="text-sm text-gray-700 mb-3 flex items-center gap-2">
                      <Timer className="w-4 h-4" />
                      How to Get There
                    </h3>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="bg-white rounded-lg p-3 text-center">
                        <Car className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                        <div className="text-xs text-gray-600">Driving</div>
                        <div className="text-sm text-gray-900">{selectedLocation.travelTime.driving}</div>
                      </div>
                      <div className="bg-white rounded-lg p-3 text-center">
                        <Bus className="w-5 h-5 text-green-600 mx-auto mb-1" />
                        <div className="text-xs text-gray-600">Transit</div>
                        <div className="text-sm text-gray-900">{selectedLocation.travelTime.transit}</div>
                      </div>
                      <div className="bg-white rounded-lg p-3 text-center">
                        <Footprints className="w-5 h-5 text-orange-600 mx-auto mb-1" />
                        <div className="text-xs text-gray-600">Walking</div>
                        <div className="text-sm text-gray-900">{selectedLocation.travelTime.walking}</div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-4 mb-5">
                  <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-yellow-700 mb-1">
                      <Star className="w-5 h-5 fill-current" />
                      <span className="text-xl text-gray-900">{selectedLocation.rating}</span>
                    </div>
                    <p className="text-xs text-gray-600">Rating</p>
                  </div>
                  <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-green-700 mb-1">
                      <DollarSign className="w-5 h-5" />
                      <span className="text-xl text-gray-900">{selectedLocation.priceRange}</span>
                    </div>
                    <p className="text-xs text-gray-600">Price</p>
                  </div>
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className={`w-5 h-5 ${selectedLocation.isOpen ? 'text-green-600' : 'text-red-600'}`} />
                      <span className="text-lg text-gray-900">{selectedLocation.isOpen ? 'Open' : 'Closed'}</span>
                    </div>
                    <p className="text-xs text-gray-600">Status</p>
                  </div>
                </div>

                <p className="text-gray-700 mb-5 leading-relaxed">{selectedLocation.description}</p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <button
                    onClick={() => handleGetDirections(selectedLocation)}
                    className="flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-3.5 rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg"
                  >
                    <Navigation2 className="w-4 h-4" />
                    <span>Directions</span>
                  </button>
                  <button
                    onClick={() => handleCall(selectedLocation.phone)}
                    className="flex items-center justify-center gap-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-3.5 rounded-xl hover:from-green-700 hover:to-green-800 transition-all shadow-lg"
                  >
                    <Phone className="w-4 h-4" />
                    <span>Call</span>
                  </button>
                  <button
                    onClick={() => handleShare(selectedLocation)}
                    className="flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white px-4 py-3.5 rounded-xl hover:from-purple-700 hover:to-purple-800 transition-all shadow-lg"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>Share</span>
                  </button>
                  <button
                    onClick={() => handleOpenInGoogleMaps(selectedLocation)}
                    className="flex items-center justify-center gap-2 bg-gradient-to-r from-orange-600 to-orange-700 text-white px-4 py-3.5 rounded-xl hover:from-orange-700 hover:to-orange-800 transition-all shadow-lg"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Open</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .leaflet-container {
          height: 100%;
          width: 100%;
        }
        
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        
        .pulse-ring {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 40px;
          height: 40px;
          border: 3px solid #4285F4;
          border-radius: 50%;
          animation: pulse-animation 2s infinite;
        }
        
        @keyframes pulse-animation {
          0% {
            opacity: 1;
            transform: translate(-50%, -50%) scale(0.5);
          }
          100% {
            opacity: 0;
            transform: translate(-50%, -50%) scale(1.5);
          }
        }
      `}</style>
    </div>
  );
}
